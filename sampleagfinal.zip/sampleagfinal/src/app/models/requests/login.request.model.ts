interface LoginRequestModel{
    Username: string,
    Password : string
}

export { LoginRequestModel }