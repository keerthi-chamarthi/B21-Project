import { Deserializable } from './deserializable.model';

describe('Deserializable', () => {
  it('should create an instance', () => {
    expect(new Deserializable()).toBeTruthy();
  });
});
