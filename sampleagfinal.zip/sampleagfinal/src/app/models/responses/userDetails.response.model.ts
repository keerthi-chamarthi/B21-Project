interface UserDetailsResponse
{
    Address : string,
    BirthDate : string,
    DisplayName : string,
    EmailID : string,
    UserID: number,
    BusinessAccountTitle: string,
    BusinessCurrencyCode: string,
}

export {UserDetailsResponse}